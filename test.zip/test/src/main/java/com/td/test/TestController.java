package com.td.test;

import com.td.test.service.ComputeService;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

  ComputeService service = new ComputeService();

  @RequestMapping("/params")
  List<String> computeQuadratic() {
    return service.compute(5,6,7);

  }
  @RequestMapping("/")
  List<String> computeQuadratic2(@RequestParam List<String> params) {

    Params p = new Params();
    p.setA(params.get(0));
    p.setB(params.get(1));
    p.setC(params.get(2));

    return service.compute(p);

  }

}
