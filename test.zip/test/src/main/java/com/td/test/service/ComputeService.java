package com.td.test.service;

import com.td.test.Params;
import java.util.ArrayList;
import java.util.List;

public class ComputeService {

  public final String NO_ROOT_FOUND = "No root found";
  public List<String> compute(Params params) {
     try {
       return compute(Integer.parseInt(params.getA()), Integer.parseInt(params.getB()),
           Integer.parseInt(params.getC()));
     } catch (NumberFormatException ex) {
       ex.printStackTrace();

     }

     return null;
  }

  //Coompute all roots
  public List<String> compute(int a, int b, int c) {

    List<String> result = new ArrayList<>();

    double discriminant = computeDiscriminant(a, b, c);
    if (discriminant < 0) {
      double real = -b / (2 * a);
      double imaginary = Math.sqrt(-discriminant) / (2 * a);
      result.add("Root1 = " + real + " + " + imaginary);
      result.add("Root2 = " + real + " + " + imaginary);

    } else if (discriminant == 0) {
      result.add("Root1 = Root2 = " + getRoot1(a, b, c));

    } else if (a == 0 && b == 0) {
      result.add(NO_ROOT_FOUND);
    } else if (a == 0) {
      double u = -c / b;
      result.add("Root1 = Root2 = " + u );

    } else {
      result.add("Root1 = " + getRoot1(a, b, c));
      result.add("Root2 = " + getRoot2(a, b, c));
    }

    return result;
  }

  public double computeDiscriminant(int a, int b, int c) {

    return Math.pow(b,2) - 4 * a * c;
  }

  public double getRoot1(int a, int b, int c) {
    return (-b + Math.sqrt(Math.pow(b,2) - (4 * a * c))) / (2 * a);

  }

  public double getRoot2(int a, int b, int c) {
    return (-b - Math.sqrt(Math.pow(b,2) - (4 * a * c))) / (2 * a);
  }

}
