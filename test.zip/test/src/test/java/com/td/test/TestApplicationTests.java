package com.td.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.td.test.service.ComputeService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestApplicationTests {

  @Test
  void contextLoads() {
    ComputeService service = new ComputeService();
    double discriminant = service.computeDiscriminant(1,2,3);
    List<String> roots = service.compute(1,2,3);

    assertEquals(discriminant,-8);
    assertEquals(roots.size() ,2);

  }

}
